from django.contrib import admin
from django.contrib.admin import SimpleListFilter
from core.models import SystemStatus
from django.utils.safestring import mark_safe
from django.db.models import Q,Count,F
from daterange_filter.filter import DateRangeFilter
from project.models import TaskStatus,TaskFile,TaskActionTimeLine,Project,Organization
from django.urls import reverse
from datetime import datetime
from dashboard.models import RectifiedFlag
from dashboard.utils.generateRectifiedReport import generate_project_report_pdf
from dashboard.utils.filterUserBasedQs import weekly_obsns_datefilter,filtered_qs_rolebased,filtered_region_rolebased,filtered_city_rolebased
from organization.models import City,Region


class StatusFilter(SimpleListFilter):
    title = 'Status' # or use _('country') for translated title
    parameter_name = 'status'

    def lookups(self, request, model_admin):
        statuses = set([c.status for c in model_admin.model.objects.order_by('status__system_code').distinct('status__system_code')])
        return [(c.id, c.name) for c in statuses]

    def queryset(self, request, queryset):

        if self.value():
            return queryset.filter(status__id__exact=self.value())

class CategoryFilter(SimpleListFilter):
    title = 'Category' # or use _('country') for translated title
    parameter_name = 'category'

    def lookups(self, request, model_admin):
        categories = set([c.category for c in model_admin.model.objects.filter(category__isnull=False).order_by('category__system_code').distinct('category__system_code')])
        if categories is not None:
            return [(c.id, c.name) for c in categories]
        return None

    def queryset(self, request, queryset):
        if self.value():
            return queryset.filter(category_id = self.value())

class CityFilter(SimpleListFilter):
    title = 'City' # or use _('country') for translated title
    parameter_name = 'project__city_id'

    def lookups(self, request, model_admin):
        cities = set([c.project.city for c in model_admin.model.objects.filter(project__city__isnull=False).order_by('project__city__code').distinct('project__city__code')])
        if cities is not None:
            return [(c.id, c.name) for c in cities]
        return None
    
    def queryset(self, request, queryset):
        if self.value():
            return queryset.filter(project__city__id__exact=self.value())

class RegionFilter(SimpleListFilter):
    title = 'Region' # or use _('country') for translated title
    parameter_name = 'project__region_id'
  
    def lookups(self, request, model_admin):
        regions = set([c.project.region for c in model_admin.model.objects.filter(project__region__isnull=False).order_by('project__region__code').distinct('project__region__code')])
        if regions is not None:
            return [(c.id, c.name) for c in regions]
        return None

    def queryset(self, request, queryset):
        if self.value():
            return queryset.filter(project__region__id__exact=self.value())

class InspectionFilter(SimpleListFilter):
    title = 'Flag Type' # or use _('country') for translated title
    parameter_name = 'status__parent_id'

    def lookups(self, request, model_admin):
        regions = set([c.status.parent for c in model_admin.model.objects.filter(status__parent__isnull=False).order_by('status__parent__code').distinct('status__parent__code')])
        if regions is not None:
            return [(c.id, c.name) for c in regions]
        return None

    def queryset(self, request, queryset):
        if self.value():
            return queryset.filter(status__parent__id = self.value())


class RectifiedFlagAdmin(admin.ModelAdmin):
    list_per_page = 10
    list_display_links = None
    list_max_show_all = 10000000000000000000000000
    change_form_template = 'admin/change_form.html'
    change_list_template = 'task_action_templates/rectified_flag_change_list.html'
    list_display = ['ca_ref_no','get_flag','get_description','created_by','created_on','action_btns']
    ordering = ['-created_on']
    list_filter = (('created_on',DateRangeFilter),InspectionFilter,RegionFilter,CityFilter,'project__organization')
    search_fields = ['serial_number','project__reference_number','status__name','created_by__email','updated_by__email','task__name','status__parent__name']
    fields = ['description','status']
    date_hierarchy = 'created_on'
    actions = [generate_project_report_pdf,]


    # Permission Based List Ammendment
    def get_list_display(self, request):
        list_display = super().get_list_display(request)
        if 'dashboard.change_rectifiedflag' in request.user.get_group_permissions():
            if 'edit_flag' not in list_display:
                list_display.append('edit_flag',)
        else:
            if 'edit_flag' in list_display:
                list_display.remove('edit_flag')
        return list_display


    """ Calculated Fields """    
    def ca_ref_no(self, obj):
        return obj.project.reference_number

    ca_ref_no.short_description = 'CA REF#'

    def get_flag(self, obj,inspection_id = None,flag_id = None):
        return mark_safe('<i class="fa fa-flag" style="color:{flag_color};font-size:25px"></i>'.format(flag_color = obj.status.color))   
    
    # get_flag.admin_order_field  = 'parent_project_taskactions'  #Allows column order sorting
    get_flag.short_description = 'Flags'  #Renames column head

    def flag_parent_type(self, obj):
        return obj.status.parent.name
    
    flag_parent_type.short_description = 'INSPECTION TYPE'


    def type_of_work(self, obj):
        return obj.task

    type_of_work.short_description = 'TYPE OF WORK'
   
    def action_btns(self, obj):
        return mark_safe("<a href ='javascript:void(0);' onclick=ChatBoxApi.ShowChatBox('{task_action_id}','{project_ref_no}') class='btn-outline-info border-0 mr-2'><i class='far fa-comment-dots text-130'>\
            </i></a><a type='button' onclick=ChatBoxApi.task_action_first_attachment('{task_action_id}') class='btn-outline-info border-0'><i class='fas fa-paperclip text-130'></i></a>".format(task_action_id = obj.id,project_ref_no = obj.project.reference_number.replace(' ', '_')))
    
    action_btns.short_description = 'ACTION'

    def get_description(self, obj):
        if obj:
            if obj.is_seen:
                return mark_safe('<p>{obsn}</p>'.format(
                    obsn = str(obj.description),
                ))
            return mark_safe('<p class="font-weight-bold">{obsn}</p>'.format(
                obsn = str(obj.description),
            ))
        else:
            return ""
    get_description.admin_order_field  = 'description'  #Allows column order sorting
    get_description.short_description = 'Obsn'  #Renames column head
    
    
    def edit_flag(self, obj):
        return mark_safe("<a href={url} style='text-align:center;'><i class='fa fa-edit text-170'></i></a>".format(
                url = reverse('admin:dashboard_rectifiedflag_change', args=[obj.pk])
            ))
    
    edit_flag.short_description = 'Edit Flag'

    def get_obsn(self, obj):
        return mark_safe('<a onclick="DashboardApi.obsnModal(\'{desc}\')" href="javascript:void(0);" class="btn btn-bold btn-outline-primary btn-h-primary fs--outline border-0 btn-a-primary radius-0 px-35 mb-1" data-toggle="tooltip" data-original-title="Flag Detail">Show Obsn</a>'.format(
                desc = str(obj.description),
        ))
    get_obsn.admin_order_field  = 'Description'  #Allows column order sorting
    get_obsn.short_description = ''  #Renames column head

   
    def changelist_view(self, request, extra_context=None):
        response = super().changelist_view(
            request, extra_context=extra_context)
        try:
            qs = response.context_data['cl'].queryset
        except (AttributeError, KeyError):
            return response

        self.request = request
        extra_context = extra_context or {}

        # Project's QS
        project_qs =  Project.objects.filter(id__in = qs.values("project_id").distinct())
        project_regions = Region.objects.filter(id__in = filtered_region_rolebased(request,project_qs),status = "active").order_by('ordering')
        project_cities = City.objects.filter(id__in = filtered_city_rolebased(request,project_qs),status = "active")
        # Region Card Filter
        region_counts = []
        region_counts_total = 0

        for region in project_regions:
            if 'drf__created_on__gte' in request.GET and 'drf__created_on__lte' in request.GET:
                count = qs.filter(project__region=region,created_on__date__gte = request.GET['drf__created_on__gte'],created_on__date__lte = request.GET['drf__created_on__lte'],end_time__isnull=True).exclude(status__system_code__in = ['system_status_task_status_material_green','system_status_task_status_inspection_green']).count()
            else:
                count = qs.filter(project__region=region,end_time__isnull=True,status__system_code__in = ['system_status_task_status_material_green','system_status_task_status_inspection_green']).count()

            region_counts_total = region_counts_total + count
            data_dict = {
                "id":str(region.id),
                "region_name":region.name,
                "region_count":count
            }
            region_counts.append(data_dict)
        extra_context['region_counts'] = list(region_counts)
        extra_context['region_counts_total'] = int(region_counts_total)

        # Station Card Filter
        cities_counts = []
        city_counts_total = 0
        
        if 'project__region_id' in request.GET:
            project_cities = project_cities.filter(region_id = request.GET['project__region_id'])
        
        elif 'project__city_id' in request.GET:
            project_cities = project_cities.filter(id = request.GET['project__city_id'])
       
        for city in project_cities:
            if 'drf__created_on__gte' in request.GET and 'drf__created_on__lte' in request.GET:
                count = qs.filter(project__city=city,created_on__date__gte = request.GET['drf__created_on__gte'],created_on__date__lte = request.GET['drf__created_on__lte'],end_time__isnull=True,status__system_code__in = ['system_status_task_status_material_green','system_status_task_status_inspection_green']).count()
            else:
                count = qs.filter(project__city=city,end_time__isnull=True,status__system_code__in = ['system_status_task_status_material_green','system_status_task_status_inspection_green']).count()
            city_counts_total = city_counts_total + count
            data_dict = {
                "id":str(city.id),
                "region_id":str(city.region.id),
                "city_name":city.name,
                "city_count":count
            }
            cities_counts.append(data_dict)

        extra_context['cities_counts'] = list(cities_counts)
        extra_context['city_counts_total'] = city_counts_total

        insp_flag_filtered_query_set = qs.filter(status__parent__system_code = "system_status_task_status_inspection")
        mat_flag_filtered_query_set = qs.filter(status__parent__system_code = "system_status_task_status_material")
        extra_context = {
             'mat_flag_filtered_query_set': self.getFlagStats(mat_flag_filtered_query_set,"material"),
             'ins_flag_filtered_query_set': self.getFlagStats(insp_flag_filtered_query_set,"inspection"),
        }

        extra_context['selected_filters'] = self.selectedFilter(request)
        extra_context['total_projects'] = Project.objects.filter().count()

        ####### Pie Chart for Inspection Flags #######
        dataset_flag_pie = list(qs.values('status__color',name = F('status__name')).annotate(y = Count('status')))
        dataset_flag_pie_color = list()
        for entry in dataset_flag_pie:
            dataset_flag_pie_color.append(entry['status__color'])
        
        ####### Pie Chart For RegionWise Inspection Distribution Of Projects #######
        region_data = list(qs.filter(status__parent__system_code = 'system_status_task_status_inspection').order_by('project__region__ordering').values(('project__region__name')).distinct().annotate(name = F('project__region__name'),y = Count('id')))
        extra_context['dataset_inspection'] = dataset_flag_pie
        extra_context['dataset_region1'] = region_data
        extra_context['dataset_color'] = dataset_flag_pie_color
   
        ####### Pie Chart For RegionWise Material Distribution Of Projects #######
        region_data = list(qs.filter(status__parent__system_code = 'system_status_task_status_material').order_by('project__region__ordering').values(('project__region__name')).distinct().annotate(name = F('project__region__name'),y = Count('id')))
        extra_context['dataset_inspection'] = dataset_flag_pie
        extra_context['dataset_region2'] = region_data
        extra_context['dataset_color'] = dataset_flag_pie_color


        # Region Card Filter
        region_counts = []
        region_counts_total = 0

        for region in project_regions:
            count = qs.filter(project__region=region).count()

            region_counts_total = region_counts_total + count
            data_dict = {
                "id":str(region.id),
                "region_name":region.name,
                "region_count":count
            }
            region_counts.append(data_dict)
        extra_context['region_counts'] = list(region_counts)
        extra_context['region_counts_total'] = int(region_counts_total)

        # Station Card Filter
        cities_counts = []
        city_counts_total = 0

        
        if 'project__region_id' in request.GET:
            project_cities = project_cities.filter(region_id = request.GET['project__region_id'])
        
        elif 'project__city_id' in request.GET:
            project_cities = project_cities.filter(id = request.GET['project__city_id'])
       
        for city in project_cities:
            count = qs.filter(project__city=city).count()
            city_counts_total = city_counts_total + count
            data_dict = {
                "id":str(city.id),
                "region_id":str(city.region.id),
                "city_name":city.name,
                "city_count":count
            }
            cities_counts.append(data_dict)

        extra_context['cities_counts'] = list(cities_counts)
        extra_context['city_counts_total'] = city_counts_total

        return super().changelist_view(request, extra_context=extra_context)

    
    def getFlagStats(self,flag_qs,flag_type=None):
        data_list = []
        if flag_type == "inspection":
            flags = SystemStatus.objects.filter(parent__system_code = "system_status_task_status_inspection")
        else:
            flags = SystemStatus.objects.filter(parent__system_code = "system_status_task_status_material")
        for entry in flags:
            entry_list = []
            entry_list.append(entry.color)
            entry_list.append(flag_qs.filter(status_id = str(entry.id)).count())
            entry_list.append(flag_qs.filter(status_id = entry.id,end_time__isnull = False).count())
            data_list.append(entry_list)
        return data_list
    

    # Selected Filter Helper  Function
    def selectedFilter(self,request):
        formatted_string = ""
        if 'flag_id' in request.GET:
            flag_id = request.GET.get('flag_id',None)
            task_status = TaskStatus.objects.filter(id = flag_id).first()
            formatted_string = formatted_string + str(task_status.parent.name) + "-" + str(task_status.name) +" /"
        
        if 'project__city_id' in request.GET:
            city_id = request.GET.get('project__city_id',None)
            city = City.objects.filter(id = city_id).first()
            formatted_string = formatted_string + str(city.region.name) + "-" + str(city.name) + "/"

        if 'project__region_id' in request.GET:
            region_id = request.GET.get('project__region_id',None)
            region = Region.objects.filter(id = region_id).first()
            formatted_string = formatted_string + str(region.name) + "/"
        
        if 'status__parent_id' in request.GET:
            status_parent_id = request.GET.get('status__parent_id',None)
            status_parent = SystemStatus.objects.filter(parent_id = status_parent_id).first()
            formatted_string = formatted_string + str(status_parent.parent.name) + "/"
        
        if 'status_id' in request.GET:
            status_id = request.GET.get('status_id',None)
            status = SystemStatus.objects.filter(id = status_id).first()
            formatted_string = formatted_string + str(status.name) + "/"
        
        if 'drf__created_on__gte' and 'drf__created_on__lte' in request.GET.keys():
            drf__created_on__gte = request.GET.get('drf__created_on__gte',None)
            drf__created_on__lte = request.GET.get('drf__created_on__lte',None)
            formatted_string = formatted_string + str(drf__created_on__gte) + "  To  " + str(drf__created_on__lte) + "/"
        
        if 'project__organization__id__exact' in request.GET:
            organization_id = request.GET.get('project__organization__id__exact',None)
            organization = Organization.objects.get(id=organization_id)
            formatted_string = formatted_string + str(organization.name) + "/"
      
        return formatted_string


    # # This will help you to disable delete functionaliyt
    def get_queryset(self, request):
        qs = self.model._default_manager.get_queryset().filter(status__system_code__in = ['system_status_task_status_material_green','system_status_task_status_inspection_green']).exclude(parent__status__system_code__in = ['system_status_task_status_material_green','system_status_task_status_inspection_green'])
        qs = qs.filter(project_id__in = filtered_qs_rolebased(request))
        time_line_obj = TaskActionTimeLine.objects.filter(user_type = request.user.type).first()
        if time_line_obj:
            time_line = datetime.now() - time_line_obj.time_line
            # qs = qs.filter(created_on__date__gte = time_line.date(),,status__system_code__in = ['system_status_task_status_material_green','system_status_task_status_inspection_green'])
            qs = qs.filter(parent__end_time__isnull=False)
        else:
            qs = qs.filter(parent__end_time__isnull=False)
        ordering = self.get_ordering(request)
        if ordering:
            qs = qs.order_by(*ordering)
        return qs.order_by('-created_on')
    
    
    def has_delete_permission(self, request, obj=None):
        if 'dashboard.can_delete_flag' in request.user.get_group_permissions(): 
            return True
        else:
            return False
    

    def has_add_permission(self, request):
        return False

    # def has_change_permission(self, request, obj=None):
    #     if 'dashboard.change_rectifiedflag' in request.user.get_group_permissions():
    #         return True
    #     else:
    #         return False

    def has_view_permission(self, request, obj=None):
        if 'dashboard.view_rectifiedflag' in request.user.get_group_permissions() or request.user.is_superuser: 
            return True
        else:
            return False

admin.site.register(RectifiedFlag,RectifiedFlagAdmin)


