from django.contrib import admin
from core.models import SystemStatus
from dashboard.models import Report
#from daterange_filter.filter import DateRangeFilter
from utils.IP import get_client_ip
from dashboard.utils.generateReport import generate_project_report_pdf
from daterange_filter.filter import DateRangeFilter
from dashboard.utils.filterUserBasedQs import filtered_qs_rolebased
from django.contrib.admin import SimpleListFilter


class CityFilter(SimpleListFilter):
    title = 'City' # or use _('country') for translated title
    parameter_name = 'city_id'

    def lookups(self, request, model_admin):
        # statuses = set([c.status for c in model_admin.model.objects.order_by('status__system_code').distinct('status__system_code')])
        cities =  set([c.city for c in model_admin.model.objects.order_by('city__code').distinct('city__code')])
        return [(c.id, c.name) for c in cities]
    def queryset(self, request, queryset):

        if self.value():
            return queryset.filter(city_id__exact=self.value())

class RegionFilter(SimpleListFilter):
    title = 'Region' # or use _('country') for translated title
    parameter_name = 'region_id'

    def lookups(self, request, model_admin):
        # statuses = set([c.status for c in model_admin.model.objects.order_by('status__system_code').distinct('status__system_code')])
        filtered_regions =  set([c.region for c in model_admin.model.objects.order_by('region__code').distinct('region__code')])
        return [(c.id, c.name) for c in filtered_regions]
    
    def queryset(self, request, queryset):
        if self.value():
            return queryset.filter(region_id__exact=self.value())

class ReportAdmin(admin.ModelAdmin):
    list_display_links = None
    list_per_page = 10
    list_max_show_all = 100000000000
    change_list_template = 'report_change_list.html'
    list_display = ('reference_number','get_project_name','contractor','updated_on')
    list_filter = ('contract_status',('created_on', DateRangeFilter),CityFilter,RegionFilter,'organization')
    readonly_fields = ["region","city","type","created_on","updated_on","created_by","updated_by"]
    search_fields = ['reference_number','name','contractor','created_on','created_by','updated_on','updated_by']
    exclude = ("ip","created_by","updated_by")
    actions = [generate_project_report_pdf,]
    date_hierarchy = 'created_on'
    ordering = ('-updated_on','-created_on')

    def get_project_name(self, obj):
        return obj.name
    get_project_name.admin_order_field  = 'name'  #Allows column order sorting
    get_project_name.short_description = 'Type Of Work'  #Renames column head

    #fields = ('name', 'image', 'description')

    fieldsets = (
        ('User & Groups Info', {
            'fields': (('users', 'groups'))
        }),
        ('Organization Info', {
            'fields': (('region','city','type'),('organization','thumbnail'))
        }),
        ('Project Info', {
            'fields': (('name','code'), ('contractor','consultant_name', 'contract_status','expenditure_total'), 'category', 'status','start_date', 'end_date', 'project_remarks')
        }),
    )
    search_fields = ('name','code','contract_status', 'created_on', 'updated_on')
    

    def formfield_for_foreignkey(self, db_field, request, **kwargs):
            
        if db_field.name == "status":
            kwargs["queryset"] = SystemStatus.objects.filter(parent__system_code__in =['system_status_project_status']) #kwargs['disabled'] = True
    
        return super().formfield_for_foreignkey(db_field, request, **kwargs)

    # This will help you to disable delete functionaliyt
    def get_queryset(self, request):
        qs = self.model._default_manager.get_queryset()
        # qs = qs.filter(region__in=request.user)
        project_ids_list = filtered_qs_rolebased(request,qs)
        qs = qs.filter(id__in = project_ids_list)
            # TODO: this should be handled by some parameter to the ChangeList.
        ordering = self.get_ordering(request)
        if ordering:
            qs = qs.order_by(*ordering)
        return qs.order_by('-created_on','-updated_on')
    
    
    
    def has_delete_permission(self, request, obj=None):
        return False

    def has_add_permission(self, request):
        return False

    def has_change_permission(self, request, obj=None):
        if request.user.is_superuser == 0:
            return True
        else:
            return False

    def has_view_permission(self, request, obj=None):
        if request.user.is_superuser == 0:
            return True
        else:
            return False

    def save_model(self, request, obj, form, change):
        if not obj.created_by:
            # Only set added_by during the first save.
            obj.created_by = request.user
        else:
            obj.updated_by = request.user
        obj.ip = get_client_ip(request)
        
        super().save_model(request, obj, form, change)
     
        if obj.region is None and obj.city is None:
            obj.region = obj.organization.region
            obj.city = obj.organization.city
        
        super().save_model(request, obj, form, change)

admin.site.register(Report,ReportAdmin)
